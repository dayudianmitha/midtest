
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Edit Penerbit</div>
                    <div class="card-body">
                            <form action="/penerbit/<?php echo e($data1->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                            <input class="form-control" type="text" name="nama_penerbit" value="<?php echo e($data1->nama_penerbit); ?>" placeholder="nama penerbit"><br>
                                <input type="submit" value="submit" class="btn btn-primary">
                            </form>
                    </div>                
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MATA KULIAH\test\test\resources\views//penerbit/editpenerbit.blade.php ENDPATH**/ ?>