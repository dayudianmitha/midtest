
<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Tambah Buku</div>
                    <div class="card-body">
                            <form action="/buku" enctype="multipart/form-data" method="POST">
                                <?php echo csrf_field(); ?>
                                Judul Buku :
                                <input type="text" name="judul_buku" required="" class="form-control"><br>
                               Pengarang :
                               <input type="text" name="pengarang" required="" class="form-control"><br>
                               Penerbit : 
                                <?php $__currentLoopData = $penerbit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="checkbox" name="nama_penerbit[]" value="<?php echo e($publish->id); ?>"><?php echo e($publish->nama_penerbit); ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <br><br>
                        <button type="submit" class="btn btn-primary" style="margin-top:10px">Submit</button>
                    </div>                
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MATA KULIAH\test\test\resources\views//buku/create.blade.php ENDPATH**/ ?>