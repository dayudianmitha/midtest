<!DOCTYPE html>
<html lang="en">
<head>
  <title>PRODUK</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="<?php echo e(URL::asset('css/bootstrap.css')); ?>" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                            <a href="/create">Tambah Produk</a>
                            <table class="table table-hover">
                                <thead>
                                    <th>No</th>
                                    <th>Nama Produk</th>
                                    <th>Harga</th>
                                    <th>Deskripsi</th>
                                    <th>Rating</th>
                                    <th>Stok</th>
                                    <th>Aksi</th>
                                    
                                </thead>
                                <tbody>
                                    
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($index['nama_produk']); ?></td>
                                    <td><?php echo e($index['harga']); ?></td>
                                    <td><?php echo e($index['deskripsi']); ?></td>
                                    <td><?php echo e($index['rating']); ?></td>
                                    <td><?php echo e($index['stok']); ?></td>
                                                        <td>
                                    <td><form action="/<?php echo e($index->id); ?>editproduk" method="GET">
                                            <?php echo csrf_field(); ?>
                                    <button class="btn btn-warning"><i class="glyphicon glyphicon-edit"></i>Edit</button>
                                        </form>
                                                        </td>
                                                        <td>
                                                            <form action="/<?php echo e($index->id); ?>/" method="POST">
                                                                <?php echo method_field("DELETE"); ?>
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" class="btn btn-danger">
                                                                    DELETE
                                                                </button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                    </div>
                </div>
            </div>
        </div>
  
</body>
</html>
<?php /**PATH E:\MATA KULIAH\test\test\resources\views/index.blade.php ENDPATH**/ ?>