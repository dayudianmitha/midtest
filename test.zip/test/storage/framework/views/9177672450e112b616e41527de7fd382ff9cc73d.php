<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="dns-prefetch" href="//fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">TestBook</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="/penerbit">Penerbit</a></li>
      <li><a href="/buku">Buku</a></li>
    </ul>
  </div>
</nav>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH E:\MATA KULIAH\test\test\resources\views/layout/app.blade.php ENDPATH**/ ?>