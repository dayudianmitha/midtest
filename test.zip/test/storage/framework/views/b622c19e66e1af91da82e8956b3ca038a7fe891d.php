
<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Tambah Penerbit</div>
                    <div class="card-body">
                            <form action="/penerbit" method="POST">
                                <?php echo csrf_field(); ?>
                                <input class="form-control" type="text" name="nama_penerbit" placeholder="nama penerbit"><br>
                                <input type="submit" value="submit" class="btn btn-primary">
                            </form>
                    </div>                
                </div>
                <br>
                <div class="card">
                        <div class="card-header">List Penerbit</div>
                        <div class="card-body">
                                <div class="table-responsive">
                                        <table class="table table-striped ">
                                            <thead>
                                                <tr>
                                                    <th>No.</th>
                                                    <th>List Penerbit</th>
                                                    <th>Edit</th>
                                                    <th>Delete</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($m->nama_penerbit); ?></td>
                                                        <td>
                                                            <form action="/penerbit/<?php echo e($m->id); ?>/edit" method="GET">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" class="btn btn-warning">
                                                                    Edit
                                                                </button>
                                                            </form>
                                                        </td>
                                                        <td>
                                                            <form action="/penerbit/<?php echo e($m->id); ?>/" method="POST">
                                                                <?php echo method_field("DELETE"); ?>
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" class="btn btn-danger">
                                                                    DELETE
                                                                </button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                        </div>                
                    </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MATA KULIAH\test\test\resources\views//penerbit/penerbit.blade.php ENDPATH**/ ?>