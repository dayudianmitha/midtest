
<?php $__env->startSection('content'); ?>

<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Edit Produk</div>
                    <div class="card-body">

                            <form action="/produk/<?php echo e($data1->id); ?>" method="POST" >
                                <?php echo e(csrf_field()); ?>

                                <?php echo method_field("PUT"); ?>
                                <input type="text" name="name" value="<?php echo e($data1->nama_produk); ?>" required="" class="form-control"><br>
                                <input type="number" name="price" value="<?php echo e($data1->harga); ?>" required="" class="form-control"><br>
                                <input type="text" name="desc" value="<?php echo e($data1->deskripsi); ?>" required="" class="form-control"><br>
                                <input type="number" name="rate" value="<?php echo e($data1->rate); ?>" required=""class="form-control"><br>
                                <input type="number" name="stock" value="<?php echo e($data1->stok); ?>" required=""class="form-control"><br>
                                <input type="submit" name="submit" value="update">
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MATA KULIAH\test\test\resources\views/produk/edit.blade.php ENDPATH**/ ?>