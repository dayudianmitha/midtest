
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Tambah Produk</div>
                    <div class="card-body">

                            <form action="/produk" enctype="multipart/form-data" method="POST">
                                <?php echo csrf_field(); ?>
                                Nama :
                                <input type="text" name="name" required="" class="form-control"><br>
                                Harga : 
                                <input type="number" name="price" required="" class="form-control"><br>
                                Rating : 
                                <input type="number" name="rate" required="" class="form-control"><br>
                                Stok : 
                                <input type="number" name="stock" required="" class="form-control"><br>
                                Deskripsi : 
                                <input type="text" name="desc" required="" class="form-control"><br>
                                <button type="submit" class="btn btn-primary" style="margin-top:10px">Submit</button>
                            </form>
                            
                    </div>                
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MATA KULIAH\test\test\resources\views//produk/create.blade.php ENDPATH**/ ?>