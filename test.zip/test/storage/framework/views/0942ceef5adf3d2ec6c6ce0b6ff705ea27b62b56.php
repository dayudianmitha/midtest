
<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">List Buku</div>
                    <div class="card-body">
                            <a href="/buku/create">Tambah Buku</a>
                            <table class="table table-hover">
                                <thead>
                                    <th>No</th>
                                    <th>Judul Buku</th>
                                    <th>Pengarang</th>

                                </thead>
                                <tbody>
                                    
                                    <?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($index->judul_buku); ?></td>
                                        <td><?php echo e($index->pengarang); ?></td>
                                        <td>
                                         <form action="/buku/editbuku<?php echo e($index->id); ?>/edit" method="GET">
                                            <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-warning">
                                            Edit
                                            </button>
                                        </form>
                                        </td>
                                        <form style="float: right;" action="/buku/<?php echo e($index->id); ?>/" method="POST">
                                        <?php echo method_field("DELETE"); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Delete<i class="fa fa-trash-o fa-fw"></i>
                                        </button>
                                    </form>
                        
                                        </td> 
                                    </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MATA KULIAH\test\test\resources\views//buku/index.blade.php ENDPATH**/ ?>