
<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">List Product</div>
                    <div class="card-body">
                            <a href="/produk/create">Tambah Produk</a>
                            <table class="table table-hover">
                                <thead>
                                    <th>No</th>
                                    <th>Nama Produk</th>
                                    <th>Harga</th>
                                    <th>Deskripsi</th>
                                    <th>Rating</th>
                                    <th>Stok</th>
                                    <th>Aksi</th>

                                    
                                    
                                </thead>
                                <tbody>
                                    
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($index['nama_produk']); ?></td>
                                        <td><?php echo e($index['harga']); ?></td>
                                        <td><?php echo e($index['deskripsi']); ?></td>
                                        <td><?php echo e($index['rating']); ?></td>
                                        <td><?php echo e($index['stok']); ?></td>
                                    
                                        <td><form action="/produk/<?php echo e($index->id); ?>/edit" method="GET">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-warning"><i class="glyphicon glyphicon-edit"></i>Edit</button>
                                            </form>
                                        </form>
                                        <form style="float: right;" action="/produk/<?php echo e($index->id); ?>/" method="POST">
                                        <?php echo method_field("DELETE"); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Delete<i class="fa fa-trash-o fa-fw" onclick="return confirm('Yakin ingin menghapus data?')"></i>
                                        </button>
                                    </form>
                        
                                        </td> 
                                    </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MATA KULIAH\test\test\resources\views/produk/index.blade.php ENDPATH**/ ?>