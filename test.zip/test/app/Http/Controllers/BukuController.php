<?php

namespace App\Http\Controllers;

use DB;
use App\Buku;
use App\Penerbit;
use App\PenerbitDetail;
use Illuminate\Http\Request;

class BukuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $index = Buku::select('tb_buku.id','judul_buku','pengarang','nama_penerbit')
        ->join('tb_penerbit_detail','tb_buku.id','=','tb_penerbit_detail.id_buku')
        ->join('tb_penerbit','tb_penerbit_detail.id_penerbit','=','tb_penerbit.id')
        ->get();

        return view("/buku/index",compact('index'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $penerbit = Penerbit::get();
        return view("/buku/create",compact('penerbit'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $buku = new Buku;
        $buku->judul_buku= $request->judul_buku;
        $buku->pengarang= $request->pengarang;

        if(is_array($request->penerbit)){
            foreach($request->penerbit as $publisher){
                $pub = new PenerbitDetail;
                $pub->id_buku = $buku->id;
                $pub->id_penerbit = $publisher;
                $pub->save();
            }
        }
        
        return redirect('/buku');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Buku  $buku
     * @return \Illuminate\Http\Response
     */
    public function show(Buku $buku)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Buku  $buku
     * @return \Illuminate\Http\Response
     */
    public function edit(Buku $buku)
    {
        $test = Buku::find($buku)->first();
        return view('/buku/edit',compact('test'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Buku  $buku
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Buku $buku)
    {
        $buku->judul_buku= $request->judul_buku;
        $buku->pengarang= $request->pengarang;
        $produk->save();
        return redirect('/buku/index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Buku  $buku
     * @return \Illuminate\Http\Response
     */
    public function destroy(Buku $buku)
    {
        Buku::where('id','=',$buku->id)->delete();
        return redirect('/buku');
    }
}
