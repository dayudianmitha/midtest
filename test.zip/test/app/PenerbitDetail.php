<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PenerbitDetail extends Model
{
    protected $table = "tb_penerbit_detail";
	protected $primarykey ="id_penerbit_detail";
	protected $fillable = [
        'id_buku','id_penerbit',
    ];
}
