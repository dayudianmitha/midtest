<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Penerbit extends Model
{
    protected $table = "tb_penerbit";
	protected $primarykey ="id";
	protected $fillable = ['nama_penerbit'];
    public $timestamps = true;
}
