<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Buku extends Model
{
    protected $table = "tb_buku";
	protected $primarykey ="id";
	protected $fillable = [
        'judul_buku','pengarang',
    ];
}
