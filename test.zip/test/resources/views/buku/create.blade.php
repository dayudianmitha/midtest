@extends('layout.app')
@section('content')
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Tambah Buku</div>
                    <div class="card-body">
                            <form action="/buku" enctype="multipart/form-data" method="POST">
                                @csrf
                                Judul Buku :
                                <input type="text" name="judul_buku" required="" class="form-control"><br>
                               Pengarang :
                               <input type="text" name="pengarang" required="" class="form-control"><br>
                               Penerbit : 
                                @foreach ($penerbit as $publish)
                                    <input type="checkbox" name="nama_penerbit[]" value="{{$publish->id}}">{{$publish->nama_penerbit}} 
                                @endforeach
                                <br><br>
                        <button type="submit" class="btn btn-primary" style="margin-top:10px">Submit</button>
                    </div>                
                </div>
            </div>
        </div>
    </div>
    @endsection