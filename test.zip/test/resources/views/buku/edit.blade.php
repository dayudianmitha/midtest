<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Edit Buku</div>
                    <div class="card-body">

                            <form action="/buku/{{$test->id}}" method="POST" >
                                {{csrf_field()}}
                                @method("PUT")
                                <input type="text" name="judul_buku" value="{{$test->judul_buku}}" required="" class="form-control"><br>
                                <input type="text" name="pengarang" value="{{$test->pengarang}}" required="" class="form-control"><br>
                                <input type="submit" name="submit" value="update">
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>