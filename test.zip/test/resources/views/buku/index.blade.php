@extends('layout.app')
@section('content')
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">List Buku</div>
                    <div class="card-body">
                            <a href="/buku/create">Tambah Buku</a>
                            <table class="table table-hover">
                                <thead>
                                    <th>No</th>
                                    <th>Judul Buku</th>
                                    <th>Pengarang</th>

                                </thead>
                                <tbody>
                                    
                                    @foreach($index as $index)
                                    
                                    <tr>
                                        <td>{{$loop->iteration}}</td>
                                        <td>{{$index->judul_buku}}</td>
                                        <td>{{$index->pengarang}}</td>
                                        <td>
                                         <form action="/buku/editbuku{{$index->id}}/edit" method="GET">
                                            @csrf
                                        <button type="submit" class="btn btn-warning">
                                            Edit
                                            </button>
                                        </form>
                                        </td>
                                        <form style="float: right;" action="/buku/{{$index->id}}/" method="POST">
                                        @method("DELETE")
                                        @csrf
                                        <button type="submit" class="btn btn-danger">Delete<i class="fa fa-trash-o fa-fw"></i>
                                        </button>
                                    </form>
                        
                                        </td> 
                                    </tr>
                                   @endforeach
                                </tbody>
                            </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection