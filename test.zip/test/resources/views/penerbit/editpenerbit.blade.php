@extends('layout.app')
@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Edit Penerbit</div>
                    <div class="card-body">
                            <form action="/penerbit/{{$data1->id}}" method="POST">
                                @csrf
                                @method('PUT')
                            <input class="form-control" type="text" name="nama_penerbit" value="{{ $data1->nama_penerbit }}" placeholder="nama penerbit"><br>
                                <input type="submit" value="submit" class="btn btn-primary">
                            </form>
                    </div>                
                </div>
            </div>
        </div>
    </div>
@endsection